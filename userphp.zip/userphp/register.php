<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Fau Campus Snapshots</title>
	<link rel="stylesheet" type="text/css" href="style.css">
    
    <style>
 body {
                    margin: 0;
                    font-family: Arial, Helvetica, sans-serif;
                    background-color: #f2f2f2;
                }

                .topnav {
                    overflow: hidden;
                    background-color: #b70006;
                    border: 0.5px solid #7c6f6f;
                }

                .topnav a {
                    float: left;
                    color: #f2f2f2;
                    text-align: center;
                    padding: 24px 36px;
                    text-decoration: none;
                    font-size: 17px;

                }

                .topnav a:hover {
                    background-color: #ddd;
                    color: black;
                }

                .topnav a.active {
                    background-color: #b70006;
                    color: white;
                }
                footer {
                    position: fixed;
                    left: 0;
                    bottom: 0;
                    right: 0;
                    background-color: #b70006;
                    color: #b70006;
                    text-align: center;
                    border: 0.5px solid #7c6f6f;

                }
        </style>
</head>
<body>
    <div>
    
    <table style="width:100%">
  <tr>
    <th><div class="topnav">
        <div>
            <a class="active" href="http://lamp.cse.fau.edu/~cen4010sum18_g03/M5/userphp/home.html">Campus Snapshots</a>
        </div></div>
</th>
    <th>
  
</table>
    
    
     
    
    
	<div class="header">
        
        
<table style="width:100%">
  <tr>
    <th><h2>FAU Campus Snapshots </h2> <br>Already a member? <br><br> <a href="login.php" class="btn" >Login</a></th>
      <th><br><th>
    <th> </th> 
      
      <th><img src="logo-owl-color.svg" alt="Cinque Terre" width="200" height="100">
   
  </tr>

</table>       
        
	</div>
        

        
	
	<form method="post" action="register.php">

		<?php include('errors.php'); ?>

        <div class="input-group">
            
                <div id=text>
                    
		<h2>Create a NEW Account</h2>
        <div>
            <br>
		<h4>Sign up to receive and post alerts <br></h4>
        <br>
        </div>
	</div>
             
            <input type="text" name="Name" value="<?php if(!empty($Name)) echo $Name; ?>" placeholder="Name">
            
        </div>
        
        <div class="input-group">
			<input type="text" name="Username" value="<?php if(!empty($Username)) echo $Username; ?>" placeholder="Username">
		</div>
        
		<div class="input-group">
			<input type="email" name="Email" value="<?php echo $Email; ?>" placeholder="Email">
		</div>
        
         <div class="input-group">
			<input type="text" name="Phone" value="<?php if(!empty($Phone)) echo $Phone; ?>" placeholder="Phone">
		</div>
          <div class="input-group">
			<input type="text" name="Role" value="<?php if(!empty($Role)) echo $Role; ?>" placeholder="Role">
		</div>
        
		<div class="input-group">
			<input type="password" name="Password_1" placeholder="Password">
		</div>
        
		<div class="input-group">
			<input type="password" name="Password_2" placeholder="Confirm password">
		</div>
        
		<div class="input-group">
                     
            
		</div>	
         <div>   
                   

             
             </div>
            
        <br><br>
        
    <input type="checkbox" name="checkbox" value="check" id="agree" /> <p>I have read and agree to the Terms and Conditions and Privacy Policy</p>
    
             <br>
    <button type="submit" class="btn" name="reg_user">Register</button></form> 
        
   
<br>
	</form>
        
        
</body>


<footer><p>Welcome to Campus Snapshots!</p></footer>
</html>



