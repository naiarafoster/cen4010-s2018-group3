<?php 
//session_start(); 
//
require('server.php');
$Username = $_SESSION['Username'];
//
if (!isset($_SESSION['Username'])) {
    $_SESSION['msg'] = "You must login first";
    header('location: login.php');
}

if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['Username']);
    header("location: login.php");
}

//

//

?>
<!DOCTYPE html>
<html>
<head>
	<title>Fau Campus Snapshots</title>
	<link rel="stylesheet" type="text/css" href="style.css">
    
    <style>
 body {
                    margin: 0;
                    font-family: Arial, Helvetica, sans-serif;
                    background-color: #f2f2f2;
                }

                .topnav {
                    overflow: hidden;
                    background-color: #b70006;
                    border: 0.5px solid #7c6f6f;
                }

                .topnav a {
                    float: left;
                    color: #f2f2f2;
                    text-align: center;
                    padding: 24px 36px;
                    text-decoration: none;
                    font-size: 17px;

                }

                .topnav a:hover {
                    background-color: #ddd;
                    color: black;
                }

                .topnav a.active {
                    background-color: #b70006;
                    color: white;
                }
                footer {
                    position: fixed;
                    left: 0;
                    bottom: 0;
                    right: 0;
                    background-color: #b70006;
                    color: #b70006;
                    text-align: center;
                    border: 0.5px solid #7c6f6f;

                }
        </style>
</head>
<body>

            <div class="topnav">
                <a class="active" href="http://lamp.cse.fau.edu/~cen4010sum18_g03/M5/userphp/home.html">FAU Snapshots Campus </a>

            </div>


            <div class="header">
                <h2> Campus Snapshots </h2>
            </div>
            <div class="content">

                <!-- notification message -->
                <?php if (isset($_SESSION['success'])) : ?>
                <div class="error success" >
                    <h3>
                        <?php 
                        echo $_SESSION['success']; 
                        unset($_SESSION['success']);
                        ?>
                    </h3>
                </div>
                <?php endif ?>
              <div class="boxtext">
                <!-- logged in user information -->
                <?php  if (isset($_SESSION['Username'])) : ?>
                  <br><img src="logo-owl-color.svg" alt="Cinque Terre" width="200" height="100"><br>
                <h3>Hi  <strong><?php echo $_SESSION['Username']; ?></strong>!</h3><br>
                <!--                -->
                 <h3> Here is your profile information</h3> <br><hr>
                
                <?php
               
                $q = "SELECT Name, Username, Email, Phone, Role FROM GENERAL_USER WHERE Username='".$_SESSION["Username"]."'";
                $r = mysqli_query($db,$q);
                $a = mysqli_fetch_assoc($r);
                echo "<br>"." Name: ".$a["Name"]."<br><br>";
                echo "Username:".$a["Username"]."<br><br>";
                echo "Role:".$a["Role"]."<br><br>";
                
                
                ?>
                
                <h5>Clink on the buttons below to start being part of the FAU Campus Snapshots </h5>
                <br>
                <h4>Start Now!</h4>
                  
                <br><br>
                <a href="http://lamp.cse.fau.edu/~cen4010sum18_g03/M5/NewAlert/" class="btn">Create a Alert</a>
                
                <a href="http://lamp.cse.fau.edu/~cen4010sum18_g03/M5/home/" class="btn">Look at alerts</a>

               </div>




                <br><br>
                <p> <a href="index.php?logout='1'" style="color: red;"class="btn">Logout</a> </p>
                <?php endif ?>

               
              

           

            </div>

        </body>
    <footer>footer</footer>
</html>